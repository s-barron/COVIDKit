 var firebaseConfig = {
    apiKey: "AIzaSyBOzf8h82Nwn6ZbqnihjTxAearJL0ud8eE",
    authDomain: "relational-2595e.firebaseapp.com",
    databaseURL: "https://relational-2595e.firebaseio.com",
    projectId: "relational-2595e",
    storageBucket: "relational-2595e.appspot.com",
    messagingSenderId: "20564661161",
    appId: "1:20564661161:web:fd1819d8ab86222c2deab8"
  };
firebase.initializeApp(firebaseConfig);

nameList = [];
companyList = [];
emailList = [];
phoneList = [];
messageList = [];

// Reference messages collection
var messagesRef = firebase.database().ref('messages');

messagesRef.on("child_added", function(data, prevChildKey) {
  var newMessage = data.val();
   nameList.push(newMessage.name);
   companyList.push(newMessage.company);
   emailList.push(newMessage.email);
   phoneList.push(newMessage.phone);
   messageList.push(newMessage.message);
  createTable();
});

function createTable(){

    var myData = "<b>Name</b> <b>Company</b> <b>Email</b> <b>Phone</b> <b>Message</b> <br>";

    for(index=0;index<nameList.length;index+=1){
      myData += nameList[index] + " " + companyList[index] + " " + emailList[index] + phoneList[index] + messageList[index] + "<br>";

    }
    document.getElementById("myTable").innerHTML = myData;


  }
